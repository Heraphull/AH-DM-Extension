import{p as r}from"./InitPlatformFromBackground-d50353cd.js";const t={platformInfoProvider:r};export{t as B};
