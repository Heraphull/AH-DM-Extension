import{b as r}from"./DefineExtensionEntry-56771f5e.js";const t={async getPlatformInfo(){return await r.runtime.getPlatformInfo()}};export{t as p};
