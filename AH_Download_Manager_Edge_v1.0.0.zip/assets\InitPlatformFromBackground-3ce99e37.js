import{b as r}from"./DefineExtensionEntry-cce2a256.js";const t={async getPlatformInfo(){return await r.runtime.getPlatformInfo()}};export{t as p};
