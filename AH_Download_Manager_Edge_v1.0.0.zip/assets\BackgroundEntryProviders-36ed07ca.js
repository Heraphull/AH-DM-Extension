import{p as r}from"./InitPlatformFromBackground-3ce99e37.js";const t={platformInfoProvider:r};export{t as B};
